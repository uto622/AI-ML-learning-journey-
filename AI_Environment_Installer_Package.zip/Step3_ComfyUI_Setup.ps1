# 自动 clone ComfyUI 到指定路径并初始化
$targetPath = "D:\AI_Platform\Projects\ComfyUI"
git clone https://github.com/comfyanonymous/ComfyUI.git $targetPath
cd $targetPath
python -m venv ..\..\Venv\ComfyUI_env
..\..\Venv\ComfyUI_env\Scripts\activate.ps1
pip install -r requirements.txt
Write-Output "ComfyUI 安装完成"