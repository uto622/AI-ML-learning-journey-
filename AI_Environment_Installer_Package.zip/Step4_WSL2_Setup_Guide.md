# WSL2 + DeepSeek 环境部署指南

1. 安装 Ubuntu（建议 22.04）并启动
2. 在 Ubuntu 中运行：
    sudo apt update && sudo apt install -y python3-pip git
3. 将 DeepSeek 项目放置在挂载目录：
    /mnt/d/AI_Platform/Projects/DeepSeek
4. 进入该目录后创建虚拟环境：
    python3 -m venv venv && source venv/bin/activate
5. 安装依赖：
    pip install torch transformers deepspeed
6. 运行模型推理脚本