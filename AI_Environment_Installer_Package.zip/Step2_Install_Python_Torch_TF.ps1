# 安装 Python 后配置环境变量
$pythonPath = "D:\AI_Platform\apps\Python3.10.10"
[System.Environment]::SetEnvironmentVariable(
  "Path",
  "$pythonPath;$pythonPath\Scripts",
  "Machine"
)
# pip 安装
Start-Process "$pythonPath\python.exe" -ArgumentList "-m pip install --upgrade pip"
Start-Process "$pythonPath\python.exe" -ArgumentList "-m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118"
Start-Process "$pythonPath\python.exe" -ArgumentList "-m pip install tensorflow==2.12"