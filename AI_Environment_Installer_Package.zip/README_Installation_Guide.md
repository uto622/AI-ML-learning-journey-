# AI 平台部署说明

## 主目录结构
- D:\AI_Platform\apps\Python3.10.10
- D:\AI_Platform\Venv\ComfyUI_env
- D:\AI_Platform\Projects\ComfyUI
- D:\AI_Platform\Projects\DeepSeek
- D:\Container\WSL2

## 安装顺序
1. 运行 Step1 清理环境
2. 安装 Python 并运行 Step2
3. 自动部署 ComfyUI：Step3
4. 按 Step4 指引安装 WSL2 Ubuntu 并配置 DeepSeek