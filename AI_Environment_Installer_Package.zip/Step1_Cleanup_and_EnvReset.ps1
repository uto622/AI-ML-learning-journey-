# 清理旧的 Python 和 CUDA 路径
$oldCudaPaths = @(
  "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v2.9",
  "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v1.8"
)
foreach ($path in $oldCudaPaths) {
  if (Test-Path $path) {
    Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
  }
}
[System.Environment]::SetEnvironmentVariable("Path", $null, "Machine")
Write-Output "环境路径已清除，请继续安装步骤。"